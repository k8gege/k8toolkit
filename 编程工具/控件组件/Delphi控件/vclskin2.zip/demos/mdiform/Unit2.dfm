object Form2: TForm2
  Left = 279
  Top = 201
  Width = 385
  Height = 217
  Caption = 'Form2'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  FormStyle = fsMDIChild
  OldCreateOrder = False
  Position = poDefault
  Visible = True
  OnActivate = FormActivate
  OnClose = FormClose
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Memo1: TMemo
    Left = 0
    Top = 41
    Width = 377
    Height = 149
    Align = alClient
    Lines.Strings = (
      'unit Unit2;'
      ''
      'interface'
      ''
      'uses'
      
        '  Windows, Messages, SysUtils, Classes, Graphics, Controls, Form' +
        's,'
      '  Dialogs, StdCtrls, WinSkinForm, ExtCtrls;'
      ''
      'type'
      '  TForm2 = class(TForm)'
      '    WinSkinForm1: TWinSkinForm;'
      '    Memo1: TMemo;'
      '  private'
      '    { Private declarations }'
      '  public'
      '    { Public declarations }'
      '  end;'
      ''
      'var'
      '  Form2: TForm2;'
      ''
      'implementation'
      ''
      'uses Unit1;'
      ''
      '{$R *.dfm}'
      ''
      'end.')
    ScrollBars = ssBoth
    TabOrder = 0
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 377
    Height = 41
    Align = alTop
    Caption = 'Panel1'
    PopupMenu = PopupMenu1
    TabOrder = 1
    object Button1: TButton
      Left = 40
      Top = 8
      Width = 75
      Height = 25
      Caption = 'Button1'
      TabOrder = 0
    end
  end
  object MainMenu1: TMainMenu
    Left = 88
    Top = 80
    object Child1: TMenuItem
      Caption = 'Child'
      object List1: TMenuItem
        Caption = 'List'
      end
      object Exit1: TMenuItem
        Caption = 'Exit'
      end
    end
    object View1: TMenuItem
      Caption = 'View'
    end
    object Help1: TMenuItem
      Caption = 'Help'
    end
  end
  object PopupMenu1: TPopupMenu
    OwnerDraw = True
    Left = 184
    Top = 88
    object N1111111111: TMenuItem
      Caption = '111111111'
    end
    object N22221: TMenuItem
      Caption = '2222'
    end
    object N33331: TMenuItem
      Caption = '3333'
    end
    object N444441: TMenuItem
      Caption = '44444'
    end
    object N5555551: TMenuItem
      Caption = '555555'
      object aaaaaaaa1: TMenuItem
        Caption = 'aaaaaaaa'
      end
      object bbbbbbbb1: TMenuItem
        Caption = 'bbbbbbbb'
      end
      object ccccccccc1: TMenuItem
        Caption = 'ccccccccc'
      end
      object ddddddddd1: TMenuItem
        Caption = 'ddddddddd'
        object ooooooooo1: TMenuItem
          Caption = 'qqqqqqqqqq'
        end
        object ppppppppppppp1: TMenuItem
          Caption = 'ppppppppppppp'
        end
        object ooooooooo2: TMenuItem
          Caption = 'ooooooooo'
        end
      end
      object eeeeeee1: TMenuItem
        Caption = 'eeeeeee'
      end
      object fffffffff1: TMenuItem
        Caption = 'fffffffff'
      end
    end
    object N666661: TMenuItem
      Caption = '66666'
    end
    object N777771: TMenuItem
      Caption = '77777'
    end
    object N888881: TMenuItem
      Caption = '88888'
    end
  end
end
