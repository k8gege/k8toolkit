unit Unit2;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, WinSkinForm, ExtCtrls, Menus, WinSkinData;

type
  TForm2 = class(TForm)
    Memo1: TMemo;
    Panel1: TPanel;
    Button1: TButton;
    MainMenu1: TMainMenu;
    Child1: TMenuItem;
    List1: TMenuItem;
    Exit1: TMenuItem;
    PopupMenu1: TPopupMenu;
    N1111111111: TMenuItem;
    N22221: TMenuItem;
    N33331: TMenuItem;
    N444441: TMenuItem;
    N5555551: TMenuItem;
    N666661: TMenuItem;
    N777771: TMenuItem;
    N888881: TMenuItem;
    aaaaaaaa1: TMenuItem;
    bbbbbbbb1: TMenuItem;
    ccccccccc1: TMenuItem;
    ddddddddd1: TMenuItem;
    eeeeeee1: TMenuItem;
    fffffffff1: TMenuItem;
    ooooooooo1: TMenuItem;
    ppppppppppppp1: TMenuItem;
    ooooooooo2: TMenuItem;
    View1: TMenuItem;
    Help1: TMenuItem;
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormActivate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form2: TForm2;

implementation

uses Unit1;

{$R *.dfm}

procedure TForm2.FormCreate(Sender: TObject);
begin
    skinaddlog(caption+' Oncreate');
end;

procedure TForm2.FormClose(Sender: TObject; var Action: TCloseAction);
begin
     action:= caFree;
end;

procedure TForm2.FormActivate(Sender: TObject);
begin
     skinaddlog(caption+' OnActive');
end;

procedure TForm2.FormDestroy(Sender: TObject);
begin
     skinaddlog(caption+' FormDestroy');
end;

end.
