unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, WinSkinform, Menus, WinSkinData, ExtCtrls, ImgList,
  ComCtrls, ToolWin;

type
  TForm1 = class(TForm)
    SkinData1: TSkinData;
    ControlBar1: TControlBar;
    Panel1: TPanel;
    ComboBox1: TComboBox;
    Button2: TButton;
    Button3: TButton;
    Button1: TButton;
    Button5: TButton;
    ImageList1: TImageList;
    MainMenu1: TMainMenu;
    File1: TMenuItem;
    FileNewItem: TMenuItem;
    FileOpenItem: TMenuItem;
    FileCloseItem: TMenuItem;
    FileSaveItem: TMenuItem;
    FileSaveAsItem: TMenuItem;
    N1: TMenuItem;
    FileExitItem: TMenuItem;
    Edit1: TMenuItem;
    CutItem: TMenuItem;
    CopyItem: TMenuItem;
    PasteItem: TMenuItem;
    Window1: TMenuItem;
    WindowCascadeItem: TMenuItem;
    WindowTileItem: TMenuItem;
    WindowTileItem2: TMenuItem;
    WindowMinimizeItem: TMenuItem;
    WindowArrangeItem: TMenuItem;
    Help1: TMenuItem;
    HelpAboutItem: TMenuItem;
    procedure Button4Click(Sender: TObject);
    procedure Exit1Click(Sender: TObject);
    procedure HElp1Click(Sender: TObject);
    procedure sdwq1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ComboBox1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Go1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
  private
    { Private declarations }
    procedure ReadSkinfile( apath : string );
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
  i:integer;

implementation

uses Unit2;

{$R *.dfm}
procedure TForm1.ReadSkinfile( apath : string );
var
  sts: Integer ;
  SR: TSearchRec;

  procedure AddFile;
  begin
    combobox1.items.add(sr.name);
  end;

begin
  sts := FindFirst( apath + '*.skn' , faAnyFile , SR );
  if sts = 0 then begin
      if ( SR.Name <> '.' ) and ( SR.Name <> '..' ) then begin
          if pos('.', SR.Name) <> 0 then
            Addfile;
      end;
      while FindNext( SR ) = 0 do begin
          if ( SR.Name <> '.' ) and ( SR.Name <> '..' ) then begin
              //Put User Feedback here if desired
//              Application.ProcessMessages;
              if Pos('.', SR.Name) <> 0 then  Addfile;
          end;
      end;
  end ;
  FindClose( SR ) ;
end;

procedure TForm1.Button4Click(Sender: TObject);
var form:Tform2;
begin
   inc(i);
   form:=Tform2.create(self);
   form.memo1.lines.insert(0,'child '+inttostr(i));
   form.caption:='child '+inttostr(i);
   form.show;
end;

procedure TForm1.Exit1Click(Sender: TObject);
begin
    close;
end;

procedure TForm1.HElp1Click(Sender: TObject);
begin
//   winskinform1.dolog('**************');
end;

procedure TForm1.sdwq1Click(Sender: TObject);
begin
   caption:=caption+' *';
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
    readskinfile('..\..\skins\');
    skinaddlog(caption+' OnCreate');
end;

procedure TForm1.ComboBox1Click(Sender: TObject);
begin
   SkinData1.skinfile:='..\..\skins\'+combobox1.text;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  close;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
   skindata1.active:= not skindata1.active;
   if skindata1.active then button3.caption:='Unskin'
   else button3.caption:='Skin';
//   Button4Click(sender);
end;

procedure TForm1.Go1Click(Sender: TObject);
begin
    Skinaddlog('**********************************');
end;

procedure TForm1.Button1Click(Sender: TObject);
var
  MyItem: TMenuItem;
  i: Integer;
begin
{    MyItem:= TMenuItem.Create(Self);
    MyItem.Caption := 'New item ';
    MainMenu1.Items.Add(MyItem);}
    File1.caption:=file1.caption+'*';
//    Sendmessage(handle,CN_UPdateMainMenu,0,0);
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
    skinaddlog('*******************');
end;

end.
