object Frame3: TFrame3
  Left = 0
  Top = 0
  Width = 303
  Height = 132
  TabOrder = 0
  object Button1: TButton
    Left = 104
    Top = 96
    Width = 75
    Height = 25
    Caption = 'Button1'
    TabOrder = 0
  end
  object CheckBox1: TCheckBox
    Left = 32
    Top = 32
    Width = 89
    Height = 17
    Caption = 'CheckBox1'
    Checked = True
    State = cbChecked
    TabOrder = 1
  end
  object RadioButton1: TRadioButton
    Left = 152
    Top = 32
    Width = 113
    Height = 17
    Caption = 'RadioButton1'
    Checked = True
    TabOrder = 2
    TabStop = True
  end
  object RadioButton2: TRadioButton
    Left = 152
    Top = 56
    Width = 113
    Height = 17
    Caption = 'RadioButton2'
    TabOrder = 3
  end
  object CheckBox2: TCheckBox
    Left = 32
    Top = 56
    Width = 97
    Height = 17
    Caption = 'CheckBox2'
    TabOrder = 4
  end
end
